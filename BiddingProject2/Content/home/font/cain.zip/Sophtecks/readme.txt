   _____   ____    ____    __  __  ______  ______  ______  __ __  _____
  / ___/  / __ \  / __ \  / / / / /_  __/ / ____/ / ____/ / //_/ / ___/
  \__ \  / / / / / /_/ / / /_/ /   / /   / __/   / /     / , <   \__ \
 ___/ / / /_/ / / ____/ / __  /   / /   / /___  / /___  / /| |  ___/ /
/____/  \____/ /_/     /_/ /_/   /_/   /_____/  \____/ /_/ |_| /____/


Thankyou for downloading a font from Sophtecks. I hope you enjoy it!

The fonts are free for personal use. But if you use them commercially, don't be stingy with your love! Instead, send a fee of US$10 to:
	
	Alan Bauchop
	4 Entrance st
	Aro Valley
	Wellington
	New Zealand

Feel free to send the font to other people, or to put it on your website, but please ensure that this text file goes with it.



	Thanks,

	Alan Bauchop